﻿using System;
using System.Collections;
using System.Collections.Generic;
using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Monocle;

namespace Celeste.Mod.Rug.Entities;

[CustomEntity(new string[] { "partline/Orb" })]

// -- orb from ch06 final cutscene in public form so the other badelines can use it -- //

public class Orb : Entity
{
    public Image Sprite;

    public BloomPoint Bloom;

    private float ease;

    public Vector2 Target;

    public Coroutine Routine;

    public float Ease
    {
        get
        {
            return ease;
        }
        set
        {
            ease = value;
            Sprite.Scale = Vector2.One * ease;
            Bloom.Alpha = ease;
        }
    }

    public Orb(Vector2 position)
        : base(position)
    {
        Add(Sprite = new Image(GFX.Game["characters/badeline/orb"]));
        Add(Bloom = new BloomPoint(0f, 32f));
        Add(Routine = new Coroutine(FloatRoutine()));
        Sprite.CenterOrigin();
        base.Depth = -10001;
    }

    public IEnumerator FloatRoutine()
    {
        Vector2 speed = Vector2.Zero;
        Ease = 0.2f;
        while (true)
        {
            Vector2 target = Target + Calc.AngleToVector(Calc.Random.NextFloat((float)Math.PI * 2f), 16f + Calc.Random.NextFloat(40f));
            float reset = 0f;
            while (reset < 1f && (target - Position).Length() > 8f)
            {
                Vector2 vector = (target - Position).SafeNormalize();
                speed += vector * 420f * Engine.DeltaTime;
                if (speed.Length() > 90f)
                {
                    speed = speed.SafeNormalize(90f);
                }
                Position += speed * Engine.DeltaTime;
                reset += Engine.DeltaTime;
                Ease = Calc.Approach(Ease, 1f, Engine.DeltaTime * 4f);
                yield return null;
            }
        }
    }

    public IEnumerator CircleRoutine(float offset)
    {
        Vector2 from = Position;
        float ease = 0f;
        Player player = base.Scene.Tracker.GetEntity<Player>();
        while (player != null)
        {
            float angleRadians = base.Scene.TimeActive * 2f + offset;
            Vector2 vector = player.Center + Calc.AngleToVector(angleRadians, 24f);
            ease = Calc.Approach(ease, 1f, Engine.DeltaTime * 2f);
            Position = from + (vector - from) * Monocle.Ease.CubeInOut(ease);
            yield return null;
        }
    }

    public IEnumerator AbsorbRoutine()
    {
        Player entity = base.Scene.Tracker.GetEntity<Player>();
        if (entity != null)
        {
            Vector2 from = Position;
            Vector2 to = entity.Center;
            for (float p = 0f; p < 1f; p += Engine.DeltaTime)
            {
                float num = Monocle.Ease.BigBackIn(p);
                Position = from + (to - from) * num;
                Ease = 0.2f + (1f - num) * 0.8f;
                yield return null;
            }
        }
    }
    public IEnumerator FakeAbsorbRoutine(Vector2 BackPos)
    {
        Player entity = base.Scene.Tracker.GetEntity<Player>();
        if (entity != null)
        {
            Vector2 from = Position;
            Vector2 to = entity.Center;
            for (float p = 0f; p < 1f; p += Engine.DeltaTime)
            {
                float num = Monocle.Ease.BigBackIn(p);
                Position = from + (to - from) * num;
                Ease = 0.2f + (1f - num) * 0.8f;
                yield return null;
            }
            for (float p = 0f; p < 1f; p += Engine.DeltaTime)
            {
                float num = Monocle.Ease.BigBackIn(p);
                Position = to - (from - to) * num;
                Ease = -0.2f + (1f - num) * 0.8f;
                yield return null;
            }
            yield return 0.25f;
            to = BackPos;
            for (float p = 0f; p < 1f; p += Engine.DeltaTime)
            {
                float num = Monocle.Ease.BigBackIn(p);
                Position = to - (from - to) * num;
                //Ease = 0.2f - (1f - num) * 0.8f;
                yield return null;
            }
        }
    }
}