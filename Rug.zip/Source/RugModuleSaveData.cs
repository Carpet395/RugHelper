namespace Celeste.Mod.Rug;

public class RugModuleSaveData : EverestModuleSaveData {

}