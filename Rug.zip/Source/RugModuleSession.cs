namespace Celeste.Mod.Rug;

public class RugModuleSession : EverestModuleSession {

}